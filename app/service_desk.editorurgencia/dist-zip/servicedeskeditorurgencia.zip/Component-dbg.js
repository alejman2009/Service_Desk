sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("servicedesk.editorurgencia.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);